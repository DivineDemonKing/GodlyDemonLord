﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrueTelegramBot
{
    class TelegramResult
    {
        public List<TelegramMessage> Result { get; set; }
      
    }
}
