﻿using System;
using System.Net;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace TrueTelegramBot
{
    class Telegram
    {
        public string Token;
        public string MyId;
        public int Offset { get; set; }
        public Telegram(string token, string myId)
        {
            Token = token;
            MyId = myId;
            Offset = 1;
        }
        public Telegram(string token, string myId, int offset)
        {
            Token = token;
            MyId = myId;
            Offset = offset;
        }
        public void SendMessage(string text)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create("https://api.telegram.org/bot" + Token + $"/sendMessage?chat_id={MyId}&text={text}");
            HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
        }
        public string GetMessage()
        {
            string token = "1859785865:AAHrnL3DJFnUuYG7M1pexYpsdaar83_h9Rc";
            string url = "https://api.telegram.org/bot" + token + "/getUpdates?offset=" + Offset + @"&allowed_updates=[""message""]&limit=1";
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
            string response;
            TelegramResult telegramResult;


            List<string> messages = new List<string>();
            using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream()))
            {
                response = streamReader.ReadToEnd();
                telegramResult = JsonConvert.DeserializeObject<TelegramResult>(response);
                if (telegramResult.Result.Count > 0)
                {
                    Offset++;
                    return telegramResult.Result[0].Message.Text;
                }
                else
                {
                    return "error";
                }
            }
        }
    }
}
