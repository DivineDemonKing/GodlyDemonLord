﻿using System;
using System.Net;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Newtonsoft.Json;

namespace TrueTelegramBot
{
    class Program
    {
        static void Main(string[] args)
        {
            string token = "1859785865:AAHrnL3DJFnUuYG7M1pexYpsdaar83_h9Rc";
            //Айди моего чата, у каждого пользователя он разный
            string myId = "703519119";

            Telegram telegram = new Telegram(token, myId, 221400694);

            bool stopReseiving = false;
            while (!stopReseiving)
            {
                Console.WriteLine(telegram.GetMessage());
            }
        }
    }
}
